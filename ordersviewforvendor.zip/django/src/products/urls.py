
from django.conf.urls import url , re_path
from django.urls import  path
from .views import (
    ProductListView,
    ProductDetailSlugView,

)

urlpatterns = [
    url(r'^$', ProductListView.as_view(), name='list'),
    re_path(r'^(?P<slug>[\w-]+)/$', ProductDetailSlugView.as_view(), name='detail'),
]
