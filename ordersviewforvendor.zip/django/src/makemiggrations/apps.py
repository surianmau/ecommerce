from django.apps import AppConfig


class MakemiggrationsConfig(AppConfig):
    name = 'makemiggrations'
