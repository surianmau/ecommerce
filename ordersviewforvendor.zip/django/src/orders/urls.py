
from django.conf.urls import url , re_path
from django.urls import  path
from .views import (
 orders_list_view
)

urlpatterns = [
    url(r'^$', orders_list_view , name='orderlist'),
]
