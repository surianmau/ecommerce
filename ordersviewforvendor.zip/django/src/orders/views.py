from django.shortcuts import render
from .models import Order
from accounts.models import User, Profile
from vendors.models import Vendor
# Create your views here.

def orders_list_view(request):
    user = request.user
    zs = Vendor.objects.all()
    ids = list(zs)
    sd= []
    for x in ids:
        s = x.slug
        sd.append(s)
    print(sd)
    es = User.objects.filter(email=user)
    ws = Profile.objects.filter(user__email=user)
    don =[]
    for x in ws:
        y =x.vendorid
        don.append(y)
    print(don)

    queryset = Order.objects.all()
    qs = Order.objects.paid()
    context = {
        'object_list': queryset,
        'paid': qs,
    }
    return render(request, "orders/list.html", context)

