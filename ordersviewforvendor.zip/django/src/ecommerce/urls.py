
from django.conf.urls import url , re_path , include
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.views import LogoutView
from django.views.generic import TemplateView
from carts.views import cart_home
from addresses.views import checkout_address_create_view , checkout_address_reuse_view
from accounts.views import LoginView , RegisterView , guest_register_view
from .views import  home_page, about_page, contact_page
from billing.views import payment_method_view , payment_method_createview
from carts.views import cart_detail_api_view

urlpatterns = [
    url(r'^$', home_page, name='home'),
    url(r'^contact/$', contact_page, name='contact'),
    url(r'^login/$', LoginView.as_view(), name='login'),
    url(r'^checkout/address/create/$',checkout_address_create_view,name='checkout_address_create'),
    url(r'^checkout/address/reuse/$',checkout_address_reuse_view,name='checkout_address_reuse'),
    url(r'^register/guest/$', guest_register_view, name='guest_register'),
    url(r'^logout/$', LogoutView.as_view() , name='logout'),
    url(r'^api/cart/$', cart_detail_api_view , name='api-cart'),
    url(r'^billing/payment-method/$', payment_method_view, name="billing-payment-method"),
    url(r'^billing/payment-method/create/$', payment_method_createview, name="billing-payment-method-endpoint"),
    url(r'^register/$', RegisterView.as_view(), name="register"),
    url(r'^about/$', about_page, name='about'),
    re_path(r'^products/',include(("products.urls", 'app_name') ,namespace="products")),
    re_path(r'^cart/',include(("carts.urls", 'app_name') ,namespace="cart")),
    re_path(r'^orders/',include(("orders.urls", 'app_name') ,namespace="orders")),
    re_path(r'^search/', include(("search.urls", 'app_name'), namespace="search")),
    re_path(r'^vendors/', include(("vendors.urls", 'app_name'), namespace="vendors")),
    url(r'^admin/', admin.site.urls),
]


if settings.DEBUG:
    urlpatterns = urlpatterns + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
