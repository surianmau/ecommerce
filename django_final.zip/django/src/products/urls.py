
from django.conf.urls import url , re_path
from django.urls import  path
from .views import (
    product_list_view,
    ProductDetailSlugView
)

urlpatterns = [
    url(r'^$', product_list_view, name='list'),
    re_path(r'^(?P<slug>[\w-]+) /$', ProductDetailSlugView.as_view(), name='detail'),

]
