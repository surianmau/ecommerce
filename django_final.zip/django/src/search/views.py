from django.shortcuts import render
from products.models import  Product
from django.views.generic import ListView
from django.http import QueryDict
# Create your views here.
class SearchProductListView(ListView):

    def get_context_data(self, *args, **kwargs):
        context = super(SearchProductListView,self).get_context_data(*args,**kwargs)
        query= self.request.GET.get('q')
        context['query'] = query
        return context


    template_name = "search/view.html"
    def get_queryset(self,*arg,**kwargs):
        request = self.request
        print(request.GET)
        query = request.GET.get('q', None)
        if query is not None:
            return Product.objects.search(query)

        return Product.objects.all()



