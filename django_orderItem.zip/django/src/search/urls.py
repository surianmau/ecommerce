
from django.conf.urls import url , re_path
from django.urls import  path
from .views import (
    SearchProductListView,

)

urlpatterns = [
    re_path(r'^$', SearchProductListView.as_view(), name='query'),

]
