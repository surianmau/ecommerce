from django.shortcuts import render ,redirect
from django.http import HttpResponse ,JsonResponse
from .forms import ContactForms

from django.contrib.auth import authenticate, login , get_user_model
def home_page(request):
    context = {
        "title": "hello",
        "context": "welcome to home page"
    }
    if request.user.is_authenticated:
        context["premium_content"] ="YEHHHHHHH"
    return render(request, "home_page.html", context)


def about_page(request):
    context = {
        "title": "about_page",
        "context" : "welcome to About Page"
    }
    return render(request, "home_page.html", context)


def contact_page(request):
    contact_form = ContactForms(request.POST or None)

    context = {
        "title": "contact_page",
        "context": "wlecome to contat PAge",
        "form": contact_form
    }
    if contact_form.is_valid():
        print(contact_form.cleaned_data)
        if request.is_ajax():
            return JsonResponse({"message":"Thank you"})

    if contact_form.errors:
        errors = contact_form.errors.as_json()
        if request.is_ajax():
            return HttpResponse(errors,status=400,content_type='application/json')
    return render(request, "contact/view.html", context)



